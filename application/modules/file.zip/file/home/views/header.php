 <!-- Navbar -->
 <nav class="main-header navbar navbar-expand navbar-dark navbar-danger navbar-hide text-sm">
 <!-- <nav class="main-header navbar navbar-expand text-sm"> -->
    <!-- Left navbar links -->
    <ul class="navbar-nav show-sidebar">
         
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto text-sm text-light">   
      <li class="nav-item dropdown">
        <a class="nav-link" href="#">
          <i class="fa fa-ellipsis-v" style="color:#dc3545;"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->